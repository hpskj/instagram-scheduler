Instagram Scheduler - ملف مشروع جاهز

ابدأ من ملف:
backend/README_AR.md

مختصر التشغيل:
1) cd backend
2) npm install
3) cp .env.example .env
4) عدّل بيانات Instagram و PUBLIC_BASE_URL
5) npm run dev

ثم افتح http://localhost:5000
